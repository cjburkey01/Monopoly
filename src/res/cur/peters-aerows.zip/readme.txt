﻿=== Peter's Aerows Cursor Set ===

By: ItsPeet (http://www.rw-designer.com/user/26484) itspeet@hotmail.com

Download: http://www.rw-designer.com/cursor-set/peters-aerows

Author's decription:

I found that the basic Aero cursors were too small on my netbook, and the larger sets were too ugly. So! I dove into Photoshop and RW Cursor Editor and tadaaa.
Hope you like 'em!

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.